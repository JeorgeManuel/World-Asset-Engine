/**
 * Deployment script (Hardhat)
 *
 * WHAT THIS DOES
 * 1) Deploy the NFT contract (ERC-721)
 * 2) Deploy the Marketplace contract pointing at that NFT contract
 * 3) Tell the NFT contract what the marketplace address is (so users can approve it easily)
 *
 * HOW TO RUN (local hardhat network):
 *   npx hardhat run scripts/deploy.js
 *
 * HOW TO RUN (Polygon Amoy testnet):
 *   npx hardhat run scripts/deploy.js --network amoy
 *
 * IMPORTANT:
 * - For testnet/mainnet, you must set PRIVATE_KEY and AMOY_RPC_URL in your environment.
 * - NEVER commit your real private key to git.
 */

const hre = require("hardhat");

// ======= Config you can change safely (no magic numbers) =======
const NFT_NAME = "World Engine NFTs";
const NFT_SYMBOL = "WENFT";

// Marketplace fee in basis points (BPS)
// 250 = 2.5%
const MARKETPLACE_FEE_BPS = 250;

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  if (!deployer) {
    // This happens when you run against a real network but didn't provide an account/private key.
    // On Hardhat local network, Hardhat injects accounts automatically.
    throw new Error(
      [
        "No deployer account available.",
        "Set PRIVATE_KEY (and optionally AMOY_RPC_URL) before deploying to testnet.",
        "",
        "PowerShell example (TEMP for this terminal session):",
        "  $env:PRIVATE_KEY = '0xYOUR_PRIVATE_KEY'",
        "  $env:AMOY_RPC_URL = 'https://rpc-amoy.polygon.technology'",
        "  npx hardhat run scripts/deploy.js --network amoy",
      ].join("\\n")
    );
  }

  console.log("Deploying with account:", deployer.address);
  console.log("Network:", hre.network.name);

  // -------- 1) Deploy NFT --------
  const NFT = await hre.ethers.getContractFactory("NFT");
  const nft = await NFT.deploy(NFT_NAME, NFT_SYMBOL, deployer.address);
  await nft.waitForDeployment();
  const nftAddress = await nft.getAddress();

  console.log("NFT deployed to:", nftAddress);

  // -------- 2) Deploy Marketplace --------
  const Marketplace = await hre.ethers.getContractFactory("Marketplace");
  const marketplace = await Marketplace.deploy(
    nftAddress,
    deployer.address, // fee recipient (treasury). For now: deployer.
    MARKETPLACE_FEE_BPS,
    deployer.address // owner of marketplace admin functions
  );
  await marketplace.waitForDeployment();
  const marketplaceAddress = await marketplace.getAddress();

  console.log("Marketplace deployed to:", marketplaceAddress);

  // -------- 3) Wire them together --------
  // This lets the NFT contract know which marketplace address to approve.
  const tx = await nft.setMarketplaceAddress(marketplaceAddress);
  await tx.wait();

  console.log("NFT marketplaceAddress set to:", marketplaceAddress);

  console.log("\nDeployment complete.");
  console.log("Copy these into your frontend later:");
  console.log("- NFT:", nftAddress);
  console.log("- Marketplace:", marketplaceAddress);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

